#!/bin/bash

#en esta parte se verifica que el número de argumentos sea correcto(en este caso 2), si no lo es, se muestra un mensaje de error
#y se muestra un ejemplo de uso
if [ "$#" -ne 2 ]; then
    echo "Número de argumentos incorrecto. Sólo se necesitan dos"
    echo "Ejemplo de uso: ./conferencia.sh origen destino"
    exit 1
fi

#en esta parte se verifica que el primer argumento sea un directorio y tenga permisos de lectura
#si no es un directorio o no tiene permisos de lectura, se muestra un mensaje de error
#y se muestra un ejemplo de uso
if test -d "$(realpath "$1")" && test -r "$(realpath "$1")"; then
    echo "El primer parametro es un directorio y tiene permisos de lectura"
else
    echo "El primer parametro no es un directorio o no tiene permisos de lectura"
    echo "Ejemplo de uso: ./conferencia.sh origen destino"
    exit 1
fi

#en esta parte se verifica que el segundo argumento sea un directorio y tenga permisos de escritura
#si no es un directorio o no tiene permisos de escritura, se muestra un mensaje de error
#y se muestra un ejemplo de uso
if test -d "$(realpath "$2")" && test -w "$(realpath "$2")"; then
    echo "El segundo parametro es un directorio y tiene permisos de escritura"
else
    echo "El segundo parametro no es un directorio o no tiene permisos de escritura"
    echo "Ejemplo de uso: ./conferencia.sh origen destino"
    exit 1
fi

#Buscamos subdirectorios que coincidan con el formato especificado en el enunciado.

#NOTA: a la hora de realizar el ejercicio, se crea un directorio con el formato y dentro se guarda el archivo con nombre modificado. De esta forma, yo
#entiendo que cada archivo tiene su carpeta, por lo que se hace la comprobación CON LA RUTA ENTERA para evitar que se sobreescriban.
#Con esto quiero justificar que se busque la ruta completa y no solo parte de ella. sala23/2023-02-11/4K se encuentra, sala23/2023-02-11/; no. 

#La búsqueda la hacemos mediante un find, el cual busca en la ruta absoluta del segundo directorio, especificándole el tipo de archivo (directorio) y
#la expresión regular a cunmplir. La expresión regular se compone de los siguientes elementos:
#   - .*/sala(2[0-9]|3[0-9]|4[0-9]|50)/[0-9]{4}-[0-9]{2}-[0-9]{2}/(HD|Full HD|4K|8K)
#    se hacen que las salas sean desde la 2 hasta la 4, pero añadiéndole los 9 posibles segundos dígitos (2[0-9]|3[0-9]|4[0-9]) y la sala 50.
#    Para la fecha, se especifica que es una combinación de 4, 2 y 2 dígitos, tomando valores de 0 a 9. (Se asumen fechas normales)
#    Por último, se especifican las 4 calidades de vídeo posibles mediante una colección de valores.
#Luego, el output de find se pasa a un grep silencioso (-q), el cual busca si hay alguna coincidencia (cualquiera, por el .). Si la encuentra, se imprime 
#un mensaje y se listan los subdirectorios
#Es importante especificar el tipo de expresión regular a utilizar, ya que por defecto, find utiliza la expresión regular básica, la cual
#no soporta ciertas funcionalidades como los grupos ()

if find "$(realpath "$2")" -type d -regextype posix-extended -regex ".*/sala(2[0-9]|3[0-9]|4[0-9]|50)/[0-9]{4}-[0-9]{2}-[0-9]{2}/(HD|Full HD|4K|8K)" | grep -q .; then
    echo "Se encontraron subdirectorios con la estructura requerida. Debe eliminarlos o almacenar una copia antes de ejecutar el programa."
    
    exit 1
fi

#aquí creamos las salas donde se van a guardar las diferentes charlas
#el -p se utiliza para que creen las carpetass internas si no existen
#nos aseguramos de que sea la ruta absoluta
for i in {20..50}; do
    mkdir -p "$(realpath "$2")/sala$i"
done


#en este for recorremos el archivo donde están todas las conferencias("$1"/* esto lo hacemos para referirnos a todos
#los archivos y subdirectorios que hay en el directorio que le pasamos como argumento)
for archivo in "$(realpath "$1")"/*; do
    #en esta parte se obtiene el nombre del archivo sin la ruta
    archivo_entrada=$(basename "$archivo")
    #en esta parte se verifica que el nombre del archivo cumpla con el formato que se pide(que sea: sala_XX_YYYY-MM-DD@HH:MM.resolution)
    if [[ "$archivo_entrada" =~ sala_([0-9]{2})_([0-9]{4}-[0-9]{2}-[0-9]{2})@([0-9]{2}:[0-9]{2})\.([a-zA-Z0-9 ]+) ]]; then
        #se obtienen los valores del número de sala, fecha, hora y resolución y se guardan en variables
        #Los valores se obtienen con la variable BASH_REMATCH, que guarda los valores que coinciden con la expresión regular
        #en cada campo
        sala=${BASH_REMATCH[1]}
        fecha=${BASH_REMATCH[2]}
        hora=${BASH_REMATCH[3]}
        resolucion=${BASH_REMATCH[4]}
        #con este for vamos a crear las distintas carpetas para las diferentes resoluciones(aunque haya charlas que no tengan esa resolucion)
        for res in HD "Full HD" 4K 8K; do

            resolucion_destino="$(realpath "$2")/sala$sala/$fecha/$res"
            mkdir -p "$resolucion_destino"
            #con esto comprobamos que si la resolución de alguna charla del archivo de origen es igual a alguna de las resoluciones que creamos
            #entonces se copia esa charla en la carpeta correspondiente
            if [[ "$res" == "$resolucion" ]]; then
                cp "$archivo" "$resolucion_destino/charla_$hora"
            fi
        done
    fi
done



