#!/bin/bash
#sort -u ordena y elimina duplicados del archivo que le pases
#utilizamos > para redireccionar la salida al archivo passwd_original en tmp
sort -u $HOME/passwd_copia.txt > /tmp/passwd_original.txt

#ahora calculamos el número de líneas antes y después de ordenar el fichero passwd_copia con wc -l
#utilizamos el < para que sólo nos muestre el número de líneas para poder hacer la resta de líneas 
lineas_originales=$(wc -l < $HOME/passwd_copia.txt)
lineas_finales=$(wc -l < /tmp/passwd_original.txt)
#restamos el número de líneas originales menos el número de líneas finales para saber cuántas líneas se han eliminado
lineas_eliminadas=$(( $lineas_originales - $lineas_finales ))

echo "Número de líneas eliminadas: $lineas_eliminadas" 
#ordenamos el fichero passwd y lo redireccionamos a passwd_ordenado en tmp para poder
#comparar los dos ficheros
sort -u /etc/passwd > /tmp/passwd_ordenado.txt

#if que comprueba si los archivos son iguales mediante diff, redirigiendo la salida a null
#por null
if(diff /tmp/passwd_original.txt /tmp/passwd_ordenado.txt > /dev/null) then 
    echo "Los archivos son iguales"

else 
    echo "Los archivos son diferentes"
fi